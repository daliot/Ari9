//
//  DenshionAudioVisualDemoAppDelegate.h
//  DenshionAudioVisualDemo
//
//  Created by Lam Pham on 2/5/10.
//  Copyright FancyRatStudios Inc. 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseAppController.h"

@interface FancyRatMeteringDemoAppDelegate : BaseAppController
@end
